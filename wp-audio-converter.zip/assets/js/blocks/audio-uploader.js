"use client"
  /**
   * Audio Uploader Block
   */
;((blocks, element, blockEditor, components) => {
  const { registerBlockType } = blocks
  const { Fragment } = element
  const { InspectorControls } = blockEditor
  const { PanelBody, SelectControl, ToggleControl } = components

  // Register block
  registerBlockType("wp-smart-audio-converter/audio-uploader", {
    title: "Audio to Text Converter",
    icon: "microphone",
    category: "media",
    attributes: {
      language: {
        type: "string",
        default: "en",
      },
      addTimestamps: {
        type: "boolean",
        default: true,
      },
      seoOptimize: {
        type: "boolean",
        default: true,
      },
    },

    edit: (props) => {
      const { attributes, setAttributes } = props
      const { language, addTimestamps, seoOptimize } = attributes

      // Language options
      const languageOptions = [
        { label: "English", value: "en" },
        { label: "Spanish", value: "es" },
        { label: "French", value: "fr" },
        { label: "German", value: "de" },
        { label: "Italian", value: "it" },
        { label: "Portuguese", value: "pt" },
        { label: "Russian", value: "ru" },
        { label: "Chinese", value: "zh" },
        { label: "Japanese", value: "ja" },
        { label: "Korean", value: "ko" },
        { label: "Hindi", value: "hi" },
        { label: "Bengali", value: "bn" },
      ]

      return (
        <Fragment>
          <InspectorControls>
            <PanelBody title="Audio to Text Settings">
              <SelectControl
                label="Language"
                value={language}
                options={languageOptions}
                onChange={(value) => setAttributes({ language: value })}
              />
              <ToggleControl
                label="Add Timestamps"
                checked={addTimestamps}
                onChange={(value) => setAttributes({ addTimestamps: value })}
              />
              <ToggleControl
                label="SEO Optimization"
                checked={seoOptimize}
                onChange={(value) => setAttributes({ seoOptimize: value })}
              />
            </PanelBody>
          </InspectorControls>

          <div className="wsatc-block-editor">
            <div className="wsatc-block-editor-content">
              <div className="wsatc-block-icon">
                <span className="dashicons dashicons-microphone"></span>
              </div>
              <div className="wsatc-block-title">
                <h3>Audio to Text Converter</h3>
                <p>Upload and transcribe audio files</p>
              </div>
            </div>
            <div className="wsatc-block-editor-settings">
              <p>
                <strong>Language:</strong> {languageOptions.find((option) => option.value === language).label}
              </p>
              <p>
                <strong>Add Timestamps:</strong> {addTimestamps ? "Yes" : "No"}
              </p>
              <p>
                <strong>SEO Optimization:</strong> {seoOptimize ? "Yes" : "No"}
              </p>
            </div>
          </div>
        </Fragment>
      )
    },

    save: () => {
      // Dynamic block, render from PHP
      return null
    },
  })
})(window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components)

