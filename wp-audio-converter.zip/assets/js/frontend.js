/**
 * Frontend JavaScript
 */
;(($) => {
  // Check if jQuery is loaded
  if (typeof jQuery === "undefined") {
    console.error("jQuery is not loaded.")
    return
  }

  // Check if wsatc_params is defined
  if (typeof wsatc_params === "undefined") {
    console.error("wsatc_params is not defined.")
    return
  }

  // DOM elements
  const dropzone = $("#wsatc-frontend-dropzone")
  const fileInput = $("#wsatc-frontend-file-input")
  const progress = $("#wsatc-frontend-progress")
  const progressBar = $("#wsatc-frontend-progress-bar")
  const progressStatus = $("#wsatc-frontend-progress-status")
  const result = $("#wsatc-frontend-result")
  const resultContent = $("#wsatc-frontend-result-content")
  const copyBtn = $("#wsatc-frontend-copy-btn")
  const downloadBtn = $("#wsatc-frontend-download-btn")

  // Variables
  let currentFile = null
  let currentTranscription = null
  let currentTranscriptionId = null
  let statusCheckInterval = null

  // Initialize
  function init() {
    // Setup dropzone
    setupDropzone()

    // Setup buttons
    setupButtons()
  }

  // Setup dropzone
  function setupDropzone() {
    dropzone.on("dragover", function (e) {
      e.preventDefault()
      e.stopPropagation()
      $(this).addClass("wsatc-dropzone-active")
    })

    dropzone.on("dragleave", function (e) {
      e.preventDefault()
      e.stopPropagation()
      $(this).removeClass("wsatc-dropzone-active")
    })

    dropzone.on("drop", function (e) {
      e.preventDefault()
      e.stopPropagation()
      $(this).removeClass("wsatc-dropzone-active")

      const files = e.originalEvent.dataTransfer.files
      if (files.length > 0) {
        handleFileSelect(files[0])
      }
    })

    dropzone.on("click", () => {
      fileInput.trigger("click")
    })

    fileInput.on("change", function () {
      if (this.files.length > 0) {
        handleFileSelect(this.files[0])
      }
    })
  }

  // Setup buttons
  function setupButtons() {
    // Copy button
    copyBtn.on("click", () => {
      const tempTextarea = $("<textarea>")
      $("body").append(tempTextarea)
      tempTextarea.val(currentTranscription).select()
      document.execCommand("copy")
      tempTextarea.remove()

      showNotice(wsatc_params.i18n.success, "Text copied to clipboard")
    })

    // Download button
    downloadBtn.on("click", () => {
      const blob = new Blob([currentTranscription], { type: "text/plain" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = "transcription.txt"
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    })
  }

  // Handle file select
  function handleFileSelect(file) {
    // Check file type
    const allowedTypes = ["audio/mpeg", "audio/wav", "audio/ogg", "audio/x-m4a"]
    if (!allowedTypes.includes(file.type)) {
      showNotice(wsatc_params.i18n.error, "Invalid file type. Allowed types: MP3, WAV, OGG, M4A")
      return
    }

    // Update UI
    $(".wsatc-dropzone-inner").html(`
            <p>${file.name}</p>
            <p class="wsatc-small">${formatFileSize(file.size)}</p>
        `)

    currentFile = file
    uploadFile()
  }

  // Upload file
  function uploadFile() {
    if (!currentFile) {
      return
    }

    // Create form data
    const formData = new FormData()
    formData.append("action", "wsatc_upload_audio")
    formData.append("nonce", wsatc_params.nonce)
    formData.append("audio_file", currentFile)

    // Show progress
    progress.removeClass("wsatc-hidden")
    progressStatus.text(wsatc_params.i18n.uploading)
    progressBar.css("width", "0%")

    // Upload file
    $.ajax({
      url: wsatc_params.ajax_url,
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      xhr: () => {
        const xhr = new window.XMLHttpRequest()
        xhr.upload.addEventListener(
          "progress",
          (e) => {
            if (e.lengthComputable) {
              const percent = Math.round((e.loaded / e.total) * 100)
              progressBar.css("width", percent + "%")
            }
          },
          false,
        )
        return xhr
      },
      success: (response) => {
        if (response.success) {
          currentTranscriptionId = response.data.transcription_id
          processAudio(response.data.file_path)
        } else {
          showError(response.data.message)
        }
      },
      error: () => {
        showError("Failed to upload file")
      },
    })
  }

  // Process audio
  function processAudio(filePath) {
    // Update progress status
    progressStatus.text(wsatc_params.i18n.processing)
    progressBar.css("width", "50%")

    // Process audio
    $.ajax({
      url: wsatc_params.ajax_url,
      type: "POST",
      data: {
        action: "wsatc_process_audio",
        nonce: wsatc_params.nonce,
        file_path: filePath,
        language: wsatc_params.language,
        add_timestamps: wsatc_params.add_timestamps,
        seo_optimize: wsatc_params.seo_optimize,
        transcription_id: currentTranscriptionId,
      },
      success: (response) => {
        if (response.success) {
          if (response.data.background) {
            // Background processing
            startStatusCheck()
          } else {
            // Direct processing
            showResult(response.data.text)
          }
        } else {
          showError(response.data.message)
        }
      },
      error: () => {
        showError("Failed to process audio")
      },
    })
  }

  // Start status check for background processing
  function startStatusCheck() {
    // Update progress status
    progressStatus.text(wsatc_params.i18n.waiting)

    // Clear any existing interval
    if (statusCheckInterval) {
      clearInterval(statusCheckInterval)
    }

    // Check status every 5 seconds
    statusCheckInterval = setInterval(checkTranscriptionStatus, 5000)
  }

  // Check transcription status
  function checkTranscriptionStatus() {
    // Update progress status
    progressStatus.text(wsatc_params.i18n.check_status)

    $.ajax({
      url: wsatc_params.ajax_url,
      type: "POST",
      data: {
        action: "wsatc_check_transcription_status",
        nonce: wsatc_params.nonce,
        transcription_id: currentTranscriptionId,
      },
      success: (response) => {
        if (response.success) {
          if (response.data.status === "completed") {
            // Stop checking
            clearInterval(statusCheckInterval)

            // Show result
            showResult(response.data.text)
          } else {
            // Still processing
            progressStatus.text(wsatc_params.i18n.waiting)
          }
        } else {
          // Error
          clearInterval(statusCheckInterval)
          showError(response.data.message)
        }
      },
      error: () => {
        clearInterval(statusCheckInterval)
        showError("Failed to check transcription status")
      },
    })
  }

  // Show result
  function showResult(text) {
    currentTranscription = text
    resultContent.html(formatTranscription(text))
    result.removeClass("wsatc-hidden")

    // Hide progress
    progress.addClass("wsatc-hidden")
  }

  // Format transcription
  function formatTranscription(text) {
    // Convert line breaks to <br>
    text = text.replace(/\n/g, "<br>")

    // Convert timestamps to spans
    text = text.replace(/\[(\d+:\d+)\]/g, '<span class="wsatc-timestamp">[$1]</span>')

    // Convert headings
    text = text.replace(/<h1>(.*?)<\/h1>/g, "<h1>$1</h1>")
    text = text.replace(/<h2>(.*?)<\/h2>/g, "<h2>$1</h2>")

    return text
  }

  // Show error
  function showError(message) {
    showNotice(wsatc_params.i18n.error, message)

    // Hide progress
    progress.addClass("wsatc-hidden")
  }

  // Show notice
  function showNotice(title, message) {
    // Remove existing notices
    $(".wsatc-notice").remove()

    const notice = $(`
            <div class="wsatc-notice">
                <div class="wsatc-notice-content">
                    <strong>${title}</strong>
                    <p>${message}</p>
                </div>
                <button class="wsatc-notice-close">×</button>
            </div>
        `)

    $("body").append(notice)

    setTimeout(() => {
      notice.addClass("wsatc-notice-show")
    }, 10)

    notice.find(".wsatc-notice-close").on("click", () => {
      notice.removeClass("wsatc-notice-show")
      setTimeout(() => {
        notice.remove()
      }, 300)
    })

    setTimeout(() => {
      notice.removeClass("wsatc-notice-show")
      setTimeout(() => {
        notice.remove()
      }, 300)
    }, 5000)
  }

  // Format file size
  function formatFileSize(bytes) {
    if (bytes === 0) return "0 Bytes"

    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))

    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  // Initialize on document ready
  $(document).ready(() => {
    init()
  })
})(jQuery)

