/**
 * Admin JavaScript
 */
;(($) => {
  // Check if jQuery is loaded
  if (typeof jQuery === "undefined") {
    console.error("jQuery is not loaded.")
    return
  }

  // Check if wsatc_params is defined
  if (typeof wsatc_params === "undefined") {
    console.error("wsatc_params is not defined.")
    return
  }

  // DOM elements
  const dropzone = $("#wsatc-dropzone")
  const fileInput = $("#wsatc-file-input")
  const uploadBtn = $("#wsatc-upload-btn")
  const languageSelect = $("#wsatc-language")
  const addTimestampsCheckbox = $("#wsatc-add-timestamps")
  const seoOptimizeCheckbox = $("#wsatc-seo-optimize")
  const progressCard = $("#wsatc-progress-card")
  const progressBar = $("#wsatc-progress-bar")
  const progressStatus = $("#wsatc-progress-status")
  const resultCard = $("#wsatc-result-card")
  const resultView = $("#wsatc-result-view")
  const resultEdit = $("#wsatc-result-edit")
  const resultTextarea = $("#wsatc-result-textarea")
  const editBtn = $("#wsatc-edit-btn")
  const saveEditBtn = $("#wsatc-save-edit-btn")
  const cancelEditBtn = $("#wsatc-cancel-edit-btn")
  const copyBtn = $("#wsatc-copy-btn")
  const createPostBtn = $("#wsatc-create-post-btn")
  const exportBtn = $("#wsatc-export-btn")
  const exportTxt = $("#wsatc-export-txt")
  const exportPdf = $("#wsatc-export-pdf")

  // Variables
  let currentFile = null
  let currentTranscription = null

  // Initialize
  function init() {
    // Setup dropzone
    setupDropzone()

    // Setup file input
    setupFileInput()

    // Setup buttons
    setupButtons()

    // Load recent transcriptions
    loadRecentTranscriptions()
  }

  // Setup dropzone
  function setupDropzone() {
    dropzone.on("dragover", function (e) {
      e.preventDefault()
      e.stopPropagation()
      $(this).addClass("wsatc-dropzone-active")
    })

    dropzone.on("dragleave", function (e) {
      e.preventDefault()
      e.stopPropagation()
      $(this).removeClass("wsatc-dropzone-active")
    })

    dropzone.on("drop", function (e) {
      e.preventDefault()
      e.stopPropagation()
      $(this).removeClass("wsatc-dropzone-active")

      const files = e.originalEvent.dataTransfer.files
      if (files.length > 0) {
        handleFileSelect(files[0])
      }
    })

    dropzone.on("click", () => {
      fileInput.trigger("click")
    })
  }

  // Setup file input
  function setupFileInput() {
    fileInput.on("change", function () {
      if (this.files.length > 0) {
        handleFileSelect(this.files[0])
      }
    })
  }

  // Setup buttons
  function setupButtons() {
    // Upload button
    uploadBtn.on("click", () => {
      if (currentFile) {
        uploadFile()
      } else {
        fileInput.trigger("click")
      }
    })

    // Edit button
    editBtn.on("click", () => {
      resultView.addClass("wsatc-hidden")
      resultEdit.removeClass("wsatc-hidden")
      resultTextarea.val(currentTranscription)
    })

    // Save edit button
    saveEditBtn.on("click", () => {
      currentTranscription = resultTextarea.val()
      resultView.html(formatTranscription(currentTranscription))
      resultEdit.addClass("wsatc-hidden")
      resultView.removeClass("wsatc-hidden")
    })

    // Cancel edit button
    cancelEditBtn.on("click", () => {
      resultEdit.addClass("wsatc-hidden")
      resultView.removeClass("wsatc-hidden")
    })

    // Copy button
    copyBtn.on("click", () => {
      const tempTextarea = $("<textarea>")
      $("body").append(tempTextarea)
      tempTextarea.val(currentTranscription).select()
      document.execCommand("copy")
      tempTextarea.remove()

      showNotice(wsatc_params.i18n.success, "Text copied to clipboard")
    })

    // Create post button
    createPostBtn.on("click", () => {
      createPost()
    })

    // Export button
    exportBtn.on("click", () => {
      $(".wsatc-export-options").toggleClass("wsatc-show")
    })

    // Export as TXT
    exportTxt.on("click", (e) => {
      e.preventDefault()
      exportAsTxt()
    })

    // Export as PDF
    exportPdf.on("click", (e) => {
      e.preventDefault()
      exportAsPdf()
    })
  }

  // Handle file select
  function handleFileSelect(file) {
    // Check file type
    const allowedTypes = ["audio/mpeg", "audio/wav", "audio/ogg", "audio/x-m4a"]
    if (!allowedTypes.includes(file.type)) {
      showNotice(wsatc_params.i18n.error, "Invalid file type. Allowed types: MP3, WAV, OGG, M4A")
      return
    }

    // Check file size
    const maxSize = Number.parseInt($("#wsatc-max-file-size").val() || 50) * 1024 * 1024 // MB to bytes
    if (file.size > maxSize) {
      showNotice(wsatc_params.i18n.error, `File size exceeds the maximum limit of ${maxSize / (1024 * 1024)} MB`)
      return
    }

    // Update UI
    $(".wsatc-dropzone-inner").html(`
            <span class="dashicons dashicons-media-audio"></span>
            <p>${file.name}</p>
            <p class="wsatc-small">${formatFileSize(file.size)}</p>
        `)

    uploadBtn.text("Upload & Transcribe")
    currentFile = file
  }

  // Upload file
  function uploadFile() {
    if (!currentFile) {
      return
    }

    // Create form data
    const formData = new FormData()
    formData.append("action", "wsatc_upload_audio")
    formData.append("nonce", wsatc_params.nonce)
    formData.append("audio_file", currentFile)

    // Show progress card
    progressCard.removeClass("wsatc-hidden")
    progressStatus.text(wsatc_params.i18n.uploading)
    progressBar.css("width", "0%")

    // Upload file
    $.ajax({
      url: wsatc_params.ajax_url,
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      xhr: () => {
        const xhr = new window.XMLHttpRequest()
        xhr.upload.addEventListener(
          "progress",
          (e) => {
            if (e.lengthComputable) {
              const percent = Math.round((e.loaded / e.total) * 100)
              progressBar.css("width", percent + "%")
            }
          },
          false,
        )
        return xhr
      },
      success: (response) => {
        if (response.success) {
          processAudio(response.data.file_path)
        } else {
          showError(response.data.message)
        }
      },
      error: () => {
        showError("Failed to upload file")
      },
    })
  }

  // Process audio
  function processAudio(filePath) {
    // Update progress status
    progressStatus.text(wsatc_params.i18n.processing)
    progressBar.css("width", "50%")

    // Get options
    const language = languageSelect.val()
    const addTimestamps = addTimestampsCheckbox.is(":checked")
    const seoOptimize = seoOptimizeCheckbox.is(":checked")

    // Process audio
    $.ajax({
      url: wsatc_params.ajax_url,
      type: "POST",
      data: {
        action: "wsatc_process_audio",
        nonce: wsatc_params.nonce,
        file_path: filePath,
        language: language,
        add_timestamps: addTimestamps,
        seo_optimize: seoOptimize,
      },
      success: (response) => {
        if (response.success) {
          showResult(response.data.text)
          loadRecentTranscriptions()
        } else {
          showError(response.data.message)
        }
      },
      error: () => {
        showError("Failed to process audio")
      },
      complete: () => {
        progressBar.css("width", "100%")
        setTimeout(() => {
          progressCard.addClass("wsatc-hidden")
        }, 500)
      },
    })
  }

  // Show result
  function showResult(text) {
    currentTranscription = text
    resultView.html(formatTranscription(text))
    resultCard.removeClass("wsatc-hidden")
  }

  // Format transcription
  function formatTranscription(text) {
    // Convert line breaks to <br>
    text = text.replace(/\n/g, "<br>")

    // Convert timestamps to spans
    text = text.replace(/\[(\d+:\d+)\]/g, '<span class="wsatc-timestamp">[$1]</span>')

    // Convert headings
    text = text.replace(/<h1>(.*?)<\/h1>/g, "<h1>$1</h1>")
    text = text.replace(/<h2>(.*?)<\/h2>/g, "<h2>$1</h2>")

    return text
  }

  // Create post
  function createPost() {
    $.ajax({
      url: wsatc_params.ajax_url,
      type: "POST",
      data: {
        action: "wsatc_create_post",
        nonce: wsatc_params.nonce,
        text: currentTranscription,
        title: "Transcription: " + currentFile.name,
      },
      success: (response) => {
        if (response.success) {
          window.location.href = response.data.edit_url
        } else {
          showError(response.data.message)
        }
      },
      error: () => {
        showError("Failed to create post")
      },
    })
  }

  // Export as TXT
  function exportAsTxt() {
    const blob = new Blob([currentTranscription], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "transcription.txt"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  // Export as PDF
  function exportAsPdf() {
    // This is a simplified version
    // In a real plugin, you would use a library like jsPDF
    const printWindow = window.open("", "_blank")
    printWindow.document.write(`
            <html>
                <head>
                    <title>Transcription</title>
                    <style>
                        body { font-family: Arial, sans-serif; line-height: 1.6; padding: 20px; }
                        h1 { color: #333; }
                        .timestamp { color: #666; font-size: 0.8em; }
                    </style>
                </head>
                <body>
                    <h1>Transcription</h1>
                    ${currentTranscription.replace(/\n/g, "<br>").replace(/\[(\d+:\d+)\]/g, '<span class="timestamp">[$1]</span>')}
                </body>
            </html>
        `)
    printWindow.document.close()
    printWindow.focus()
    setTimeout(() => {
      printWindow.print()
    }, 500)
  }

  // Load recent transcriptions
  function loadRecentTranscriptions() {
    $.ajax({
      url: wsatc_params.ajax_url,
      type: "POST",
      data: {
        action: "wsatc_get_recent_transcriptions",
        nonce: wsatc_params.nonce,
      },
      success: (response) => {
        if (response.success && response.data.transcriptions) {
          renderRecentTranscriptions(response.data.transcriptions)
        }
      },
    })
  }

  // Render recent transcriptions
  function renderRecentTranscriptions(transcriptions) {
    if (transcriptions.length === 0) {
      $("#wsatc-recent-transcriptions").html("<p>No recent transcriptions found.</p>")
      return
    }

    let html = '<ul class="wsatc-transcription-list">'

    transcriptions.forEach((transcription) => {
      html += `
                <li>
                    <div class="wsatc-transcription-item">
                        <div class="wsatc-transcription-info">
                            <strong>${transcription.file_name}</strong>
                            <span>${transcription.date}</span>
                        </div>
                        <div class="wsatc-transcription-actions">
                            <button class="button button-small wsatc-load-transcription" data-id="${transcription.id}">Load</button>
                            <button class="button button-small wsatc-delete-transcription" data-id="${transcription.id}">Delete</button>
                        </div>
                    </div>
                </li>
            `
    })

    html += "</ul>"

    $("#wsatc-recent-transcriptions").html(html)

    // Add event listeners
    $(".wsatc-load-transcription").on("click", function () {
      const id = $(this).data("id")
      loadTranscription(id)
    })

    $(".wsatc-delete-transcription").on("click", function () {
      const id = $(this).data("id")
      if (confirm(wsatc_params.i18n.confirm_delete)) {
        deleteTranscription(id)
      }
    })
  }

  // Load transcription
  function loadTranscription(id) {
    $.ajax({
      url: wsatc_params.ajax_url,
      type: "POST",
      data: {
        action: "wsatc_get_transcription",
        nonce: wsatc_params.nonce,
        id: id,
      },
      success: (response) => {
        if (response.success) {
          showResult(response.data.text)
        } else {
          showError(response.data.message)
        }
      },
      error: () => {
        showError("Failed to load transcription")
      },
    })
  }

  // Delete transcription
  function deleteTranscription(id) {
    $.ajax({
      url: wsatc_params.ajax_url,
      type: "POST",
      data: {
        action: "wsatc_delete_transcription",
        nonce: wsatc_params.nonce,
        id: id,
      },
      success: (response) => {
        if (response.success) {
          loadRecentTranscriptions()
        } else {
          showError(response.data.message)
        }
      },
      error: () => {
        showError("Failed to delete transcription")
      },
    })
  }

  // Show error
  function showError(message) {
    showNotice(wsatc_params.i18n.error, message)
  }

  // Show notice
  function showNotice(title, message) {
    const notice = $(`
            <div class="wsatc-notice">
                <div class="wsatc-notice-content">
                    <strong>${title}</strong>
                    <p>${message}</p>
                </div>
                <button class="wsatc-notice-close">×</button>
            </div>
        `)

    $("body").append(notice)

    setTimeout(() => {
      notice.addClass("wsatc-notice-show")
    }, 10)

    notice.find(".wsatc-notice-close").on("click", () => {
      notice.removeClass("wsatc-notice-show")
      setTimeout(() => {
        notice.remove()
      }, 300)
    })

    setTimeout(() => {
      notice.removeClass("wsatc-notice-show")
      setTimeout(() => {
        notice.remove()
      }, 300)
    }, 5000)
  }

  // Format file size
  function formatFileSize(bytes) {
    if (bytes === 0) return "0 Bytes"

    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))

    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  // Initialize on document ready
  $(document).ready(() => {
    init()
  })
})(jQuery)

