<?php
// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete options
delete_option('wsatc_engine_type');
delete_option('wsatc_default_language');
delete_option('wsatc_max_file_size');
delete_option('wsatc_seo_optimization');
delete_option('wsatc_add_timestamps');
delete_option('wsatc_requirements_met');
delete_option('wsatc_requirements_messages');
delete_option('wsatc_transcriptions');

// Delete uploaded files
$upload_dir = wp_upload_dir();
$wsatc_dir = $upload_dir['basedir'] . '/wsatc-audio';

if (file_exists($wsatc_dir)) {
    // Function to delete directory recursively
    function wsatc_delete_directory($dir) {
        if (!file_exists($dir)) {
            return true;
        }
        
        if (!is_dir($dir)) {
            return unlink($dir);
        }
        
        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }
            
            if (!wsatc_delete_directory($dir . DIRECTORY_SEPARATOR . $item)) {
                return false;
            }
        }
        
        return rmdir($dir);
    }
    
    wsatc_delete_directory($wsatc_dir);
}

// Clear scheduled events
wp_clear_scheduled_hook('wsatc_cleanup_temp_files');
wp_clear_scheduled_hook('wsatc_download_default_model');

