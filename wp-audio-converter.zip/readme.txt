=== WP Smart Audio to Text Converter ===
Contributors: yourname
Tags: audio, transcription, speech-to-text, voice, accessibility
Requires at least: 5.0
Tested up to: 6.3
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Convert audio files to text within WordPress without requiring external APIs.

== Description ==

WP Smart Audio to Text Converter allows you to transcribe audio files directly within WordPress without relying on external APIs. Upload audio files and get text transcriptions that you can use in posts, pages, or anywhere else.

= Features =

* Upload and transcribe audio files directly in WordPress
* Support for MP3, WAV, OGG, and M4A formats
* Multiple language support
* SEO optimization for transcribed text
* Add timestamps to mark different sections
* Create posts directly from transcriptions
* Gutenberg block for frontend usage
* No external API keys required

= How It Works =

The plugin uses a built-in speech recognition engine that works entirely on your server. For better results, it can also use Vosk or Whisper.cpp if they are installed on your server.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/wp-smart-audio-converter` directory, or install the plugin through the WordPress plugins screen.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Go to 'Audio to Text' in your admin menu to use the plugin.

= Optional: Advanced Setup for Better Results =

For better transcription quality, you can install additional speech recognition engines:

**Vosk**
1. Install Python and pip on your server
2. Install Vosk: `pip install vosk`
3. Download language models from https://alphacephei.com/vosk/models

**Whisper.cpp**
1. Install Whisper.cpp on your server: https://github.com/ggerganov/whisper.cpp
2. Download language models as instructed in the Whisper.cpp documentation

== Frequently Asked Questions ==

= Does this plugin require an API key? =
No, this plugin works entirely on your server without requiring any external API keys.

= What audio formats are supported? =
The plugin supports MP3, WAV, OGG, and M4A formats.

= How accurate is the transcription? =
The accuracy depends on the audio quality and the speech recognition engine used. The built-in engine provides basic functionality, while Vosk and Whisper.cpp (if installed) provide better results.

= Can I transcribe audio in languages other than English? =
Yes, the plugin supports multiple languages. The built-in engine has basic support for several languages, while Vosk and Whisper.cpp support many more languages with better accuracy.

= Will this work on shared hosting? =
Yes, the plugin is designed to work on shared hosting environments. It uses a fallback mechanism when server resources are limited.

== Screenshots ==

1. Admin interface for uploading and transcribing audio files
2. Transcription result with timestamps and SEO optimization
3. Gutenberg block for frontend usage

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
Initial release

