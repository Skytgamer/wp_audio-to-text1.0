<?php
/**
 * Plugin Name: WP Smart Audio to Text Converter
 * Description: Convert audio files to text within WordPress without external APIs
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: wp-smart-audio-converter
 * Requires at least: 5.0
 * Requires PHP: 7.2
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WSATC_VERSION', '1.0.0');
define('WSATC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WSATC_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once WSATC_PLUGIN_DIR . 'includes/class-wsatc-loader.php';
require_once WSATC_PLUGIN_DIR . 'includes/class-wsatc-admin.php';
require_once WSATC_PLUGIN_DIR . 'includes/class-wsatc-processor.php';
require_once WSATC_PLUGIN_DIR . 'includes/class-wsatc-transcriber.php';
require_once WSATC_PLUGIN_DIR . 'includes/class-wsatc-model-manager.php';
require_once WSATC_PLUGIN_DIR . 'includes/class-wsatc-compatibility.php';

/**
 * Main plugin class
 */
class WP_Smart_Audio_Converter {
    
    /**
     * Plugin instance
     */
    private static $instance = null;
    
    /**
     * Get plugin instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    public function __construct() {
        // Initialize plugin
        add_action('plugins_loaded', array($this, 'init'));
        
        // Register activation/deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Load text domain
        load_plugin_textdomain('wp-smart-audio-converter', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        // Initialize compatibility layer
        $compatibility = new WSATC_Compatibility();
        $compatibility->init();
        
        // Initialize admin
        $admin = new WSATC_Admin();
        $admin->init();
        
        // Initialize processor
        $processor = new WSATC_Processor();
        $processor->init();
        
        // Initialize model manager
        $model_manager = new WSATC_Model_Manager();
        $model_manager->init();
        
        // Add Gutenberg block
        add_action('init', array($this, 'register_blocks'));
        
        // Add AJAX handlers
        add_action('wp_ajax_wsatc_upload_audio', array($this, 'handle_audio_upload'));
        add_action('wp_ajax_nopriv_wsatc_upload_audio', array($this, 'handle_audio_upload'));
        
        // Add background processing hooks
        add_action('wsatc_process_audio_background', array($this, 'process_audio_background'), 10, 3);
    }
    
    /**
     * Register Gutenberg blocks
     */
    public function register_blocks() {
        // Check if Gutenberg is available
        if (!function_exists('register_block_type')) {
            return;
        }
        
        // Register block script
        wp_register_script(
            'wsatc-block',
            WSATC_PLUGIN_URL . 'assets/js/blocks/audio-uploader.js',
            array('wp-blocks', 'wp-element', 'wp-editor', 'wp-components'),
            WSATC_VERSION
        );
        
        // Register block editor styles
        wp_register_style(
            'wsatc-block-editor',
            WSATC_PLUGIN_URL . 'assets/css/block-editor.css',
            array(),
            WSATC_VERSION
        );
        
        // Register block
        register_block_type('wp-smart-audio-converter/audio-uploader', array(
            'editor_script' => 'wsatc-block',
            'editor_style' => 'wsatc-block-editor',
            'render_callback' => array($this, 'render_audio_uploader_block')
        ));
    }
    
    /**
     * Handle audio file upload
     */
    public function handle_audio_upload() {
        // Check nonce
        if (!check_ajax_referer('wsatc_upload_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => __('Security check failed', 'wp-smart-audio-converter')));
        }
        
        // Check file
        if (empty($_FILES['audio_file'])) {
            wp_send_json_error(array('message' => __('No file uploaded', 'wp-smart-audio-converter')));
        }
        
        // Get file info
        $file = $_FILES['audio_file'];
        $file_name = sanitize_file_name($file['name']);
        $file_type = $file['type'];
        
        // Check file size
        $max_file_size = get_option('wsatc_max_file_size', 50) * 1024 * 1024; // MB to bytes
        if ($file['size'] > $max_file_size) {
            wp_send_json_error(array('message' => sprintf(__('File size exceeds the maximum limit of %s MB', 'wp-smart-audio-converter'), $max_file_size / (1024 * 1024))));
        }
        
        // Check file type
        $allowed_types = array('audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/x-m4a');
        if (!in_array($file_type, $allowed_types)) {
            wp_send_json_error(array('message' => __('Invalid file type. Allowed types: MP3, WAV, OGG, M4A', 'wp-smart-audio-converter')));
        }
        
        // Create uploads directory if it doesn't exist
        $upload_dir = wp_upload_dir();
        $wsatc_dir = $upload_dir['basedir'] . '/wsatc-audio';
        if (!file_exists($wsatc_dir)) {
            wp_mkdir_p($wsatc_dir);
        }
        
        // Generate unique filename
        $file_name = wp_unique_filename($wsatc_dir, $file_name);
        $new_file_path = $wsatc_dir . '/' . $file_name;
        
        // Move file to uploads directory
        if (move_uploaded_file($file['tmp_name'], $new_file_path)) {
            // File uploaded successfully
            wp_send_json_success(array(
                'message' => __('File uploaded successfully', 'wp-smart-audio-converter'),
                'file_name' => $file_name,
                'file_path' => $new_file_path,
                'file_url' => $upload_dir['baseurl'] . '/wsatc-audio/' . $file_name,
                'transcription_id' => md5($new_file_path . time())
            ));
        } else {
            wp_send_json_error(array('message' => __('Failed to upload file', 'wp-smart-audio-converter')));
        }
    }
    
    /**
     * Process audio in background
     */
    public function process_audio_background($file_path, $language, $options) {
        // Get transcriber
        $transcriber = new WSATC_Transcriber();
        
        // Process audio
        $result = $transcriber->transcribe($file_path, $language);
        
        if (!$result['success']) {
            return;
        }
        
        // Post-process text
        $text = $result['text'];
        $segments = $result['segments'];
        
        // Add timestamps if requested
        if (!empty($options['add_timestamps']) && !empty($segments)) {
            $text_with_timestamps = '';
            foreach ($segments as $segment) {
                $start_time = $this->format_time($segment['start']);
                $text_with_timestamps .= '[' . $start_time . '] ' . $segment['text'] . "\n\n";
            }
            $text = $text_with_timestamps;
        }
        
        // SEO optimization if requested
        if (!empty($options['seo_optimize'])) {
            $processor = new WSATC_Processor();
            $text = $processor->optimize_for_seo($text);
        }
        
        // Save transcription
        $transcription_data = array(
            'id' => $options['transcription_id'],
            'file_name' => basename($file_path),
            'language' => $language,
            'text' => $text,
            'segments' => $segments,
            'date' => current_time('mysql'),
            'add_timestamps' => !empty($options['add_timestamps']),
            'seo_optimize' => !empty($options['seo_optimize']),
            'status' => 'completed'
        );
        
        $processor = new WSATC_Processor();
        $processor->save_transcription($options['transcription_id'], $transcription_data);
    }
    
    /**
     * Format time in seconds to MM:SS format
     */
    private function format_time($seconds) {
        $minutes = floor($seconds / 60);
        $seconds = $seconds % 60;
        return sprintf('%02d:%02d', $minutes, $seconds);
    }
    
    /**
     * Render audio uploader block
     */
    public function render_audio_uploader_block($attributes) {
        // Enqueue frontend scripts and styles
        wp_enqueue_style('wsatc-frontend', WSATC_PLUGIN_URL . 'assets/css/frontend.css', array(), WSATC_VERSION);
        wp_enqueue_script('wsatc-frontend', WSATC_PLUGIN_URL . 'assets/js/frontend.js', array('jquery'), WSATC_VERSION, true);
        
        // Localize script
        wp_localize_script('wsatc-frontend', 'wsatc_params', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wsatc_upload_nonce'),
            'language' => isset($attributes['language']) ? $attributes['language'] : 'en',
            'add_timestamps' => isset($attributes['addTimestamps']) ? $attributes['addTimestamps'] : true,
            'seo_optimize' => isset($attributes['seoOptimize']) ? $attributes['seoOptimize'] : true,
            'i18n' => array(
                'uploading' => __('Uploading...', 'wp-smart-audio-converter'),
                'processing' => __('Processing...', 'wp-smart-audio-converter'),
                'success' => __('Success!', 'wp-smart-audio-converter'),
                'error' => __('Error:', 'wp-smart-audio-converter'),
                'waiting' => __('Waiting for transcription...', 'wp-smart-audio-converter'),
                'check_status' => __('Checking status...', 'wp-smart-audio-converter')
            )
        ));
        
        ob_start();
        ?>
        <div class="wsatc-frontend">
            <div class="wsatc-uploader">
                <div class="wsatc-dropzone" id="wsatc-frontend-dropzone">
                    <div class="wsatc-dropzone-inner">
                        <p><?php _e('Drag & drop audio file here or click to upload', 'wp-smart-audio-converter'); ?></p>
                        <p class="wsatc-small"><?php _e('Supported formats: MP3, WAV, OGG, M4A', 'wp-smart-audio-converter'); ?></p>
                    </div>
                    <input type="file" id="wsatc-frontend-file-input" class="wsatc-file-input" accept=".mp3,.wav,.ogg,.m4a" />
                </div>
                
                <div class="wsatc-progress wsatc-hidden" id="wsatc-frontend-progress">
                    <div class="wsatc-progress-bar" id="wsatc-frontend-progress-bar"></div>
                    <p id="wsatc-frontend-progress-status"><?php _e('Uploading...', 'wp-smart-audio-converter'); ?></p>
                </div>
                
                <div class="wsatc-result wsatc-hidden" id="wsatc-frontend-result">
                    <h3><?php _e('Transcription Result', 'wp-smart-audio-converter'); ?></h3>
                    <div class="wsatc-result-content" id="wsatc-frontend-result-content"></div>
                    <div class="wsatc-result-actions">
                        <button id="wsatc-frontend-copy-btn" class="wsatc-btn"><?php _e('Copy Text', 'wp-smart-audio-converter'); ?></button>
                        <button id="wsatc-frontend-download-btn" class="wsatc-btn"><?php _e('Download as TXT', 'wp-smart-audio-converter'); ?></button>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create necessary directories
        $upload_dir = wp_upload_dir();
        $wsatc_dir = $upload_dir['basedir'] . '/wsatc-audio';
        if (!file_exists($wsatc_dir)) {
            wp_mkdir_p($wsatc_dir);
        }
        
        // Create models directory
        $models_dir = WSATC_PLUGIN_DIR . 'models';
        if (!file_exists($models_dir)) {
            wp_mkdir_p($models_dir);
        }
        
        // Create .htaccess file to protect audio files
        $htaccess_file = $wsatc_dir . '/.htaccess';
        if (!file_exists($htaccess_file)) {
            $htaccess_content = "Order deny,allow\nDeny from all\n";
            file_put_contents($htaccess_file, $htaccess_content);
        }
        
        // Set default options
        add_option('wsatc_engine_type', 'built_in');
        add_option('wsatc_default_language', 'en');
        add_option('wsatc_max_file_size', 50);
        add_option('wsatc_seo_optimization', 1);
        add_option('wsatc_add_timestamps', 1);
        
        // Check system requirements
        $this->check_requirements();
        
        // Schedule model download
        wp_schedule_single_event(time() + 10, 'wsatc_download_default_model');
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clean up temporary files
        $upload_dir = wp_upload_dir();
        $wsatc_temp_dir = $upload_dir['basedir'] . '/wsatc-audio/temp';
        if (file_exists($wsatc_temp_dir)) {
            $this->delete_directory($wsatc_temp_dir);
        }
        
        // Clear scheduled events
        wp_clear_scheduled_hook('wsatc_cleanup_temp_files');
        wp_clear_scheduled_hook('wsatc_download_default_model');
    }
    
    /**
     * Check system requirements
     */
    private function check_requirements() {
        $requirements_met = true;
        $messages = array();
        
        // Check PHP version
        if (version_compare(PHP_VERSION, '7.2', '<')) {
            $requirements_met = false;
            $messages[] = __('PHP 7.2 or higher is required. Your PHP version: ', 'wp-smart-audio-converter') . PHP_VERSION;
        }
        
        // Check memory limit
        $memory_limit = ini_get('memory_limit');
        $memory_limit_bytes = $this->convert_to_bytes($memory_limit);
        if ($memory_limit_bytes < 128 * 1024 * 1024) { // 128MB
            $requirements_met = false;
            $messages[] = __('Memory limit should be at least 128MB. Current limit: ', 'wp-smart-audio-converter') . $memory_limit;
        }
        
        // Check max execution time
        $max_execution_time = ini_get('max_execution_time');
        if ($max_execution_time != 0 && $max_execution_time < 60) { // 1 minute
            $requirements_met = false;
            $messages[] = __('Max execution time should be at least 60 seconds. Current limit: ', 'wp-smart-audio-converter') . $max_execution_time;
        }
        
        // Check FFmpeg (optional)
        $ffmpeg_check = $this->check_command_exists('ffmpeg');
        if (!$ffmpeg_check) {
            $messages[] = __('FFmpeg not found. Using built-in audio processing.', 'wp-smart-audio-converter');
        }
        
        // Store requirements check result
        update_option('wsatc_requirements_met', $requirements_met);
        update_option('wsatc_requirements_messages', $messages);
    }
    
    /**
     * Check if command exists
     */
    private function check_command_exists($command) {
        if (function_exists('exec')) {
            $whereIsCommand = (PHP_OS == 'WINNT') ? 'where' : 'which';
            $process = @exec("$whereIsCommand $command 2>&1", $output, $return_var);
            return $return_var === 0;
        }
        return false;
    }
    
    /**
     * Convert PHP memory limit to bytes
     */
    private function convert_to_bytes($value) {
        $value = trim($value);
        $last = strtolower($value[strlen($value) - 1]);
        $value = (int) $value;
        
        switch ($last) {
            case 'g':
                $value *= 1024;
            case 'm':
                $value *= 1024;
            case 'k':
                $value *= 1024;
        }
        
        return $value;
    }
    
    /**
     * Delete directory recursively
     */
    private function delete_directory($dir) {
        if (!file_exists($dir)) {
            return true;
        }
        
        if (!is_dir($dir)) {
            return unlink($dir);
        }
        
        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }
            
            if (!$this->delete_directory($dir . DIRECTORY_SEPARATOR . $item)) {
                return false;
            }
        }
        
        return rmdir($dir);
    }
}

// Initialize plugin
WP_Smart_Audio_Converter::get_instance();

