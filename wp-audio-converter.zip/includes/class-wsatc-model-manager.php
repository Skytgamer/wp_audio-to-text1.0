<?php
/**
 * Model manager class
 */
class WSATC_Model_Manager {
    
    /**
     * Initialize model manager
     */
    public function init() {
        // Add AJAX handlers
        add_action('wp_ajax_wsatc_download_model', array($this, 'download_model'));
        
        // Add action for downloading default model
        add_action('wsatc_download_default_model', array($this, 'download_default_model'));
    }
    
    /**
     * Download model via AJAX
     */
    public function download_model() {
        // Check nonce
        if (!check_ajax_referer('wsatc_admin_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => __('Security check failed', 'wp-smart-audio-converter')));
        }
        
        // Check if user has permission
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('You do not have permission to download models', 'wp-smart-audio-converter')));
        }
        
        // Check model type
        if (empty($_POST['model_type'])) {
            wp_send_json_error(array('message' => __('No model type provided', 'wp-smart-audio-converter')));
        }
        
        $model_type = sanitize_text_field($_POST['model_type']);
        $language = isset($_POST['language']) ? sanitize_text_field($_POST['language']) : 'en';
        
        // Download model
        $result = $this->download_model_file($model_type, $language);
        
        if ($result['success']) {
            wp_send_json_success(array(
                'message' => __('Model downloaded successfully', 'wp-smart-audio-converter'),
                'model_path' => $result['model_path']
            ));
        } else {
            wp_send_json_error(array('message' => $result['message']));
        }
    }
    
    /**
     * Download default model
     */
    public function download_default_model() {
        // Check if default model exists
        $default_model_path = WSATC_PLUGIN_DIR . 'models/built_in/en.json';
        
        if (!file_exists($default_model_path)) {
            // Create models directory
            $models_dir = WSATC_PLUGIN_DIR . 'models/built_in';
            if (!file_exists($models_dir)) {
                wp_mkdir_p($models_dir);
            }
            
            // Download default model
            $this->download_model_file('built_in', 'en');
        }
    }
    
    /**
     * Download model file
     */
    private function download_model_file($model_type, $language) {
        // Create models directory
        $models_dir = WSATC_PLUGIN_DIR . 'models/' . $model_type;
        if (!file_exists($models_dir)) {
            wp_mkdir_p($models_dir);
        }
        
        // Get model URL
        $model_url = $this->get_model_url($model_type, $language);
        
        if (!$model_url) {
            return array(
                'success' => false,
                'message' => __('Model not available for this language', 'wp-smart-audio-converter')
            );
        }
        
        // Get model file path
        $model_file = $this->get_model_filename($model_type, $language);
        $model_path = $models_dir . '/' . $model_file;
        
        // Download model
        $response = wp_remote_get($model_url, array(
            'timeout' => 300,
            'stream' => true,
            'filename' => $model_path
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        if (wp_remote_retrieve_response_code($response) !== 200) {
            return array(
                'success' => false,
                'message' => __('Failed to download model', 'wp-smart-audio-converter')
            );
        }
        
        return array(
            'success' => true,
            'model_path' => $model_path
        );
    }
    
    /**
     * Get model URL
     */
    private function get_model_url($model_type, $language) {
        // Model URLs
        $model_urls = array(
            'built_in' => array(
                'en' => 'https://example.com/models/built_in/en.json',
                'es' => 'https://example.com/models/built_in/es.json',
                'fr' => 'https://example.com/models/built_in/fr.json',
                'de' => 'https://example.com/models/built_in/de.json'
            ),
            'vosk' => array(
                'en' => 'https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip',
                'es' => 'https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip',
                'fr' => 'https://alphacephei.com/vosk/models/vosk-model-small-fr-0.22.zip',
                'de' => 'https://alphacephei.com/vosk/models/vosk-model-small-de-0.15.zip'
            ),
            'whisper' => array(
                'en' => 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.en.bin',
                'multilingual' => 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin'
            )
        );
        
        // Return model URL if available
        if (isset($model_urls[$model_type][$language])) {
            return $model_urls[$model_type][$language];
        } elseif ($model_type === 'whisper' && $language !== 'en') {
            return $model_urls[$model_type]['multilingual'];
        }
        
        return false;
    }
    
    /**
     * Get model filename
     */
    private function get_model_filename($model_type, $language) {
        switch ($model_type) {
            case 'built_in':
                return $language . '.json';
            case 'vosk':
                return 'vosk-model-small-' . $language . '.zip';
            case 'whisper':
                return ($language === 'en') ? 'ggml-base.en.bin' : 'ggml-base.bin';
            default:
                return $language . '.model';
        }
    }
    
    /**
     * Get available models
     */
    public function get_available_models() {
        $models = array();
        
        // Check built-in models
        $built_in_dir = WSATC_PLUGIN_DIR . 'models/built_in';
        if (file_exists($built_in_dir)) {
            $files = glob($built_in_dir . '/*.json');
            foreach ($files as $file) {
                $language = pathinfo($file, PATHINFO_FILENAME);
                $models['built_in'][$language] = $file;
            }
        }
        
        // Check Vosk models
        $vosk_dir = WSATC_PLUGIN_DIR . 'models/vosk';
        if (file_exists($vosk_dir)) {
            $files = glob($vosk_dir . '/*.zip');
            foreach ($files as $file) {
                $filename = basename($file);
                if (preg_match('/vosk-model-small-([a-z]{2})/', $filename, $matches)) {
                    $language = $matches[1];
                    $models['vosk'][$language] = $file;
                }
            }
        }
        
        // Check Whisper models
        $whisper_dir = WSATC_PLUGIN_DIR . 'models/whisper';
        if (file_exists($whisper_dir)) {
            $files = glob($whisper_dir . '/*.bin');
            foreach ($files as $file) {
                $filename = basename($file);
                if ($filename === 'ggml-base.en.bin') {
                    $models['whisper']['en'] = $file;
                } elseif ($filename === 'ggml-base.bin') {
                    $models['whisper']['multilingual'] = $file;
                }
            }
        }
        
        return $models;
    }
}

