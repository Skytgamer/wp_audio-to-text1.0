<?php
/**
 * Compatibility class for shared hosting environments
 */
class WSATC_Compatibility {
    
    /**
     * Initialize compatibility layer
     */
    public function init() {
        // Add AJAX handlers for background processing
        add_action('wp_ajax_wsatc_process_audio', array($this, 'handle_process_audio'));
        add_action('wp_ajax_nopriv_wsatc_process_audio', array($this, 'handle_process_audio'));
        add_action('wp_ajax_wsatc_check_transcription_status', array($this, 'check_transcription_status'));
        add_action('wp_ajax_nopriv_wsatc_check_transcription_status', array($this, 'check_transcription_status'));
        
        // Add cron event for background processing
        add_action('wsatc_process_chunk', array($this, 'process_audio_chunk'), 10, 4);
    }
    
    /**
     * Handle audio processing request
     */
    public function handle_process_audio() {
        // Check nonce
        if (!check_ajax_referer('wsatc_admin_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => __('Security check failed', 'wp-smart-audio-converter')));
        }
        
        // Check file path
        if (empty($_POST['file_path'])) {
            wp_send_json_error(array('message' => __('No file path provided', 'wp-smart-audio-converter')));
        }
        
        $file_path = sanitize_text_field($_POST['file_path']);
        if (!file_exists($file_path)) {
            wp_send_json_error(array('message' => __('File not found', 'wp-smart-audio-converter')));
        }
        
        // Get options
        $language = isset($_POST['language']) ? sanitize_text_field($_POST['language']) : 'en';
        $add_timestamps = isset($_POST['add_timestamps']) ? (bool) $_POST['add_timestamps'] : true;
        $seo_optimize = isset($_POST['seo_optimize']) ? (bool) $_POST['seo_optimize'] : true;
        $transcription_id = isset($_POST['transcription_id']) ? sanitize_text_field($_POST['transcription_id']) : md5($file_path . time());
        
        // Check if we should use background processing
        $use_background = $this->should_use_background_processing($file_path);
        
        if ($use_background) {
            // Save initial transcription data
            $transcription_data = array(
                'id' => $transcription_id,
                'file_name' => basename($file_path),
                'language' => $language,
                'text' => '',
                'segments' => array(),
                'date' => current_time('mysql'),
                'add_timestamps' => $add_timestamps,
                'seo_optimize' => $seo_optimize,
                'status' => 'processing'
            );
            
            $processor = new WSATC_Processor();
            $processor->save_transcription($transcription_id, $transcription_data);
            
            // Schedule background processing
            $this->schedule_background_processing($file_path, $language, array(
                'add_timestamps' => $add_timestamps,
                'seo_optimize' => $seo_optimize,
                'transcription_id' => $transcription_id
            ));
            
            // Return processing status
            wp_send_json_success(array(
                'message' => __('Audio processing started', 'wp-smart-audio-converter'),
                'transcription_id' => $transcription_id,
                'status' => 'processing',
                'background' => true
            ));
        } else {
            // Process directly
            $transcriber = new WSATC_Transcriber();
            $result = $transcriber->transcribe($file_path, $language);
            
            if (!$result['success']) {
                wp_send_json_error(array('message' => $result['message']));
            }
            
            // Post-process text
            $text = $result['text'];
            $segments = $result['segments'];
            
            // Add timestamps if requested
            if ($add_timestamps && !empty($segments)) {
                $text_with_timestamps = '';
                foreach ($segments as $segment) {
                    $start_time = $this->format_time($segment['start']);
                    $text_with_timestamps .= '[' . $start_time . '] ' . $segment['text'] . "\n\n";
                }
                $text = $text_with_timestamps;
            }
            
            // SEO optimization if requested
            if ($seo_optimize) {
                $processor = new WSATC_Processor();
                $text = $processor->optimize_for_seo($text);
            }
            
            // Save transcription
            $transcription_data = array(
                'id' => $transcription_id,
                'file_name' => basename($file_path),
                'language' => $language,
                'text' => $text,
                'segments' => $segments,
                'date' => current_time('mysql'),
                'add_timestamps' => $add_timestamps,
                'seo_optimize' => $seo_optimize,
                'status' => 'completed'
            );
            
            $processor = new WSATC_Processor();
            $processor->save_transcription($transcription_id, $transcription_data);
            
            // Return result
            wp_send_json_success(array(
                'message' => __('Audio processed successfully', 'wp-smart-audio-converter'),
                'transcription_id' => $transcription_id,
                'text' => $text,
                'segments' => $segments,
                'status' => 'completed',
                'background' => false
            ));
        }
    }
    
    /**
     * Check transcription status
     */
    public function check_transcription_status() {
        // Check nonce
        if (!check_ajax_referer('wsatc_admin_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => __('Security check failed', 'wp-smart-audio-converter')));
        }
        
        // Check transcription ID
        if (empty($_POST['transcription_id'])) {
            wp_send_json_error(array('message' => __('No transcription ID provided', 'wp-smart-audio-converter')));
        }
        
        $transcription_id = sanitize_text_field($_POST['transcription_id']);
        
        // Get transcription
        $transcriptions = get_option('wsatc_transcriptions', array());
        
        if (!isset($transcriptions[$transcription_id])) {
            wp_send_json_error(array('message' => __('Transcription not found', 'wp-smart-audio-converter')));
        }
        
        $transcription = $transcriptions[$transcription_id];
        
        // Return status
        wp_send_json_success(array(
            'status' => $transcription['status'],
            'text' => isset($transcription['text']) ? $transcription['text'] : '',
            'segments' => isset($transcription['segments']) ? $transcription['segments'] : array()
        ));
    }
    
    /**
     * Determine if we should use background processing
     */
    private function should_use_background_processing($file_path) {
        // Check file size
        $file_size = filesize($file_path);
        $threshold = 5 * 1024 * 1024; // 5MB
        
        // Check max execution time
        $max_execution_time = ini_get('max_execution_time');
        
        // Use background processing for large files or short execution times
        return ($file_size > $threshold || ($max_execution_time != 0 && $max_execution_time < 120));
    }
    
    /**
     * Schedule background processing
     */
    private function schedule_background_processing($file_path, $language, $options) {
        // Get audio duration
        $duration = $this->get_audio_duration($file_path);
        
        if ($duration > 0) {
            // Split into chunks of 30 seconds
            $chunk_size = 30;
            $chunks = ceil($duration / $chunk_size);
            
            // Schedule processing for each chunk
            for ($i = 0; $i < $chunks; $i++) {
                $start = $i * $chunk_size;
                $end = min(($i + 1) * $chunk_size, $duration);
                
                wp_schedule_single_event(time() + ($i * 10), 'wsatc_process_chunk', array(
                    $file_path,
                    $language,
                    array($start, $end),
                    $options
                ));
            }
        } else {
            // If we can't determine duration, process the whole file
            wp_schedule_single_event(time() + 10, 'wsatc_process_audio_background', array(
                $file_path,
                $language,
                $options
            ));
        }
    }
    
    /**
     * Process audio chunk
     */
    public function process_audio_chunk($file_path, $language, $time_range, $options) {
        // Get transcriber
        $transcriber = new WSATC_Transcriber();
        
        // Process chunk
        $result = $transcriber->transcribe_chunk($file_path, $language, $time_range);
        
        if (!$result['success']) {
            return;
        }
        
        // Get existing transcription
        $transcriptions = get_option('wsatc_transcriptions', array());
        $transcription_id = $options['transcription_id'];
        
        if (!isset($transcriptions[$transcription_id])) {
            return;
        }
        
        $transcription = $transcriptions[$transcription_id];
        
        // Append text and segments
        $text = isset($transcription['text']) ? $transcription['text'] : '';
        $segments = isset($transcription['segments']) ? $transcription['segments'] : array();
        
        $text .= $result['text'] . ' ';
        $segments = array_merge($segments, $result['segments']);
        
        // Update transcription
        $transcription['text'] = $text;
        $transcription['segments'] = $segments;
        
        // Check if all chunks are processed
        $all_chunks_processed = true;
        
        // If all chunks are processed, finalize transcription
        if ($all_chunks_processed) {
            // Post-process text
            if (!empty($options['add_timestamps']) && !empty($segments)) {
                $text_with_timestamps = '';
                foreach ($segments as $segment) {
                    $start_time = $this->format_time($segment['start']);
                    $text_with_timestamps .= '[' . $start_time . '] ' . $segment['text'] . "\n\n";
                }
                $transcription['text'] = $text_with_timestamps;
            }
            
            // SEO optimization if requested
            if (!empty($options['seo_optimize'])) {
                $processor = new WSATC_Processor();
                $transcription['text'] = $processor->optimize_for_seo($transcription['text']);
            }
            
            // Mark as completed
            $transcription['status'] = 'completed';
        }
        
        // Save updated transcription
        $transcriptions[$transcription_id] = $transcription;
        update_option('wsatc_transcriptions', $transcriptions);
    }
    
    /**
     * Get audio duration
     */
    private function get_audio_duration($file_path) {
        // Try to use FFmpeg if available
        if (function_exists('exec')) {
            $command = "ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 " . escapeshellarg($file_path);
            $duration = (float) trim(@exec($command));
            
            if ($duration > 0) {
                return $duration;
            }
        }
        
        // Fallback: estimate based on file size
        $file_size = filesize($file_path);
        $bytes_per_second = 16000; // Rough estimate for 16kHz mono audio
        
        return $file_size / $bytes_per_second;
    }
    
    /**
     * Format time in seconds to MM:SS format
     */
    private function format_time($seconds) {
        $minutes = floor($seconds / 60);
        $seconds = $seconds % 60;
        return sprintf('%02d:%02d', $minutes, $seconds);
    }
}

