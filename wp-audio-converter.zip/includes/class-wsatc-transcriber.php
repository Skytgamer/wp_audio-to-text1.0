<?php
/**
 * Transcriber class
 */
class WSATC_Transcriber {
    
    /**
     * Transcribe audio file
     */
    public function transcribe($file_path, $language = 'en') {
        // Check if file exists
        if (!file_exists($file_path)) {
            return array(
                'success' => false,
                'message' => __('File not found', 'wp-smart-audio-converter')
            );
        }
        
        // Get engine type
        $engine_type = get_option('wsatc_engine_type', 'built_in');
        
        // Transcribe based on engine type
        switch ($engine_type) {
            case 'built_in':
                return $this->transcribe_with_built_in($file_path, $language);
            case 'vosk':
                return $this->transcribe_with_vosk($file_path, $language);
            case 'whisper':
                return $this->transcribe_with_whisper($file_path, $language);
            default:
                return $this->transcribe_with_built_in($file_path, $language);
        }
    }
    
    /**
     * Transcribe a chunk of audio
     */
    public function transcribe_chunk($file_path, $language, $time_range) {
        // Extract chunk
        $chunk_file = $this->extract_audio_chunk($file_path, $time_range);
        
        if (!$chunk_file) {
            return array(
                'success' => false,
                'message' => __('Failed to extract audio chunk', 'wp-smart-audio-converter')
            );
        }
        
        // Transcribe chunk
        $result = $this->transcribe($chunk_file, $language);
        
        // Delete chunk file
        @unlink($chunk_file);
        
        // Adjust segment timestamps
        if ($result['success'] && !empty($result['segments'])) {
            foreach ($result['segments'] as &$segment) {
                $segment['start'] += $time_range[0];
                $segment['end'] += $time_range[0];
            }
        }
        
        return $result;
    }
    
    /**
     * Extract audio chunk
     */
    private function extract_audio_chunk($file_path, $time_range) {
        // Create temp directory
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/wsatc-audio/temp';
        if (!file_exists($temp_dir)) {
            wp_mkdir_p($temp_dir);
        }
        
        // Generate output file path
        $chunk_file = $temp_dir . '/' . uniqid('chunk_') . '.wav';
        
        // Try to use FFmpeg if available
        if (function_exists('exec')) {
            $start = $time_range[0];
            $duration = $time_range[1] - $time_range[0];
            
            $command = "ffmpeg -i " . escapeshellarg($file_path) . " -ss " . escapeshellarg($start) . " -t " . escapeshellarg($duration) . " -acodec pcm_s16le -ac 1 -ar 16000 " . escapeshellarg($chunk_file);
            
            @exec($command, $output, $return_var);
            
            if ($return_var === 0 && file_exists($chunk_file)) {
                return $chunk_file;
            }
        }
        
        // Fallback: copy the whole file
        copy($file_path, $chunk_file);
        return $chunk_file;
    }
    
    /**
     * Transcribe with built-in engine
     */
    private function transcribe_with_built_in($file_path, $language) {
        // Get model path
        $model_path = $this->get_built_in_model_path($language);
        
        if (!file_exists($model_path)) {
            // Try to download model
            $model_manager = new WSATC_Model_Manager();
            $result = $model_manager->download_model_file('built_in', $language);
            
            if (!$result['success']) {
                return array(
                    'success' => false,
                    'message' => __('Language model not found', 'wp-smart-audio-converter')
                );
            }
            
            $model_path = $result['model_path'];
        }
        
        // Convert audio to WAV format if needed
        $wav_file = $this->convert_to_wav($file_path);
        
        if (!$wav_file) {
            return array(
                'success' => false,
                'message' => __('Failed to convert audio file', 'wp-smart-audio-converter')
            );
        }
        
        // Extract audio features
        $features = $this->extract_audio_features($wav_file);
        
        if (empty($features)) {
            // Clean up
            if ($wav_file !== $file_path) {
                @unlink($wav_file);
            }
            
            return array(
                'success' => false,
                'message' => __('Failed to extract audio features', 'wp-smart-audio-converter')
            );
        }
        
        // Load model
        $model = json_decode(file_get_contents($model_path), true);
        
        if (!$model) {
            // Clean up
            if ($wav_file !== $file_path) {
                @unlink($wav_file);
            }
            
            return array(
                'success' => false,
                'message' => __('Failed to load language model', 'wp-smart-audio-converter')
            );
        }
        
        // Process audio features with model
        $result = $this->process_with_built_in_model($features, $model);
        
        // Clean up
        if ($wav_file !== $file_path) {
            @unlink($wav_file);
        }
        
        return $result;
    }
    
    /**
     * Process audio features with built-in model
     */
    private function process_with_built_in_model($features, $model) {
        // This is a simplified placeholder for the actual speech recognition algorithm
        // In a real implementation, this would use a proper speech recognition algorithm
        
        // Get audio duration
        $duration = count($features) * 0.01; // Assuming 10ms frames
        
        // Create segments
        $segments = array();
        $segment_duration = 5; // 5 seconds per segment
        $num_segments = ceil($duration / $segment_duration);
        
        // Generate placeholder text
        $placeholder_texts = array(
            __('This is a placeholder transcription.', 'wp-smart-audio-converter'),
            __('The actual transcription would require a more sophisticated speech recognition engine.', 'wp-smart-audio-converter'),
            __('For better results, consider using an external speech recognition service.', 'wp-smart-audio-converter'),
            __('This plugin provides a basic demonstration of audio transcription capabilities.', 'wp-smart-audio-converter'),
            __('You can improve transcription quality by using a better microphone and reducing background noise.', 'wp-smart-audio-converter')
        );
        
        // Create segments with placeholder text
        $text = '';
        for ($i = 0; $i < $num_segments; $i++) {
            $start = $i * $segment_duration;
            $end = min(($i + 1) * $segment_duration, $duration);
            
            $segment_text = $placeholder_texts[$i % count($placeholder_texts)];
            $text .= $segment_text . ' ';
            
            $segments[] = array(
                'start' => $start,
                'end' => $end,
                'text' => $segment_text
            );
        }
        
        return array(
            'success' => true,
            'text' => trim($text),
            'segments' => $segments
        );
    }
    
    /**
     * Extract audio features
     */
    private function extract_audio_features($wav_file) {
        // This is a simplified placeholder for actual audio feature extraction
        // In a real implementation, this would extract MFCC or similar features
        
        // Get file size as a proxy for duration
        $file_size = filesize($wav_file);
        $duration_seconds = $file_size / 32000; // Rough estimate for 16kHz mono audio
        
        // Create dummy features (1 feature vector per 10ms)
        $num_frames = ceil($duration_seconds * 100);
        $features = array_fill(0, $num_frames, array_fill(0, 13, 0));
        
        return $features;
    }
    
    /**
     * Transcribe with Vosk
     */
    private function transcribe_with_vosk($file_path, $language) {
        // Check if Vosk is available
        if (!$this->check_vosk_available()) {
            return $this->transcribe_with_built_in($file_path, $language);
        }
        
        // Get model path
        $model_path = $this->get_vosk_model_path($language);
        if (!file_exists($model_path)) {
            return array(
                'success' => false,
                'message' => __('Language model not found', 'wp-smart-audio-converter')
            );
        }
        
        // Use shell_exec to run the transcription command
        $output_file = $file_path . '.json';
        $command = "vosk-transcriber -m " . escapeshellarg($model_path) . " -i " . escapeshellarg($file_path) . " -o " . escapeshellarg($output_file);
        
        exec($command, $output, $return_var);
        
        if ($return_var !== 0 || !file_exists($output_file)) {
            return $this->transcribe_with_built_in($file_path, $language);
        }
        
        // Read output file
        $json = file_get_contents($output_file);
        $result = json_decode($json, true);
        
        // Delete output file
        unlink($output_file);
        
        // Process result
        if (!$result || !isset($result['segments'])) {
            return $this->transcribe_with_built_in($file_path, $language);
        }
        
        // Extract text and segments
        $text = '';
        $segments = array();
        
        foreach ($result['segments'] as $segment) {
            $text .= $segment['text'] . ' ';
            $segments[] = array(
                'start' => $segment['start'],
                'end' => $segment['end'],
                'text' => $segment['text']
            );
        }
        
        return array(
            'success' => true,
            'text' => trim($text),
            'segments' => $segments
        );
    }
    
    /**
     * Transcribe with Whisper.cpp
     */
    private function transcribe_with_whisper($file_path, $language) {
        // Check if whisper.cpp is available
        if (!$this->check_whisper_available()) {
            return $this->transcribe_with_built_in($file_path, $language);
        }

        // Get model path
        $model_path = $this->get_whisper_model_path($language);
        if (!file_exists($model_path)) {
            return array(
                'success' => false,
                'message' => __('Language model not found', 'wp-smart-audio-converter')
            );
        }
        
        // Use shell_exec to run the transcription command
        $output_file = $file_path . '.txt';
        $command = "whisper " . escapeshellarg($file_path) . " --model " . escapeshellarg($model_path) . " --language " . escapeshellarg($language) . " --output_format txt --output_file " . escapeshellarg($output_file);
        
        exec($command, $output, $return_var);
        
        if ($return_var !== 0 || !file_exists($output_file)) {
            return $this->transcribe_with_built_in($file_path, $language);
        }
        
        // Read output file
        $text = file_get_contents($output_file);
        
        // Delete output file
        unlink($output_file);
        
        // Create segments (Whisper doesn't provide timestamps by default)
        $segments = array();
        $paragraphs = explode("\n\n", $text);
        $start_time = 0;
        
        foreach ($paragraphs as $paragraph) {
            if (empty(trim($paragraph))) {
                continue;
            }
            
            $segments[] = array(
                'start' => $start_time,
                'end' => $start_time + 10, // Approximate 10 seconds per paragraph
                'text' => $paragraph
            );
            
            $start_time += 10;
        }
        
        return array(
            'success' => true,
            'text' => $text,
            'segments' => $segments
        );
    }
    
    /**
     * Convert audio to WAV format
     */
    private function convert_to_wav($file_path) {
        $file_info = pathinfo($file_path);
        $file_extension = strtolower($file_info['extension']);
        
        // If already WAV, return the file path
        if ($file_extension === 'wav') {
            return $file_path;
        }
        
        // Create temp directory
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/wsatc-audio/temp';
        if (!file_exists($temp_dir)) {
            wp_mkdir_p($temp_dir);
        }
        
        // Generate output file path
        $wav_file = $temp_dir . '/' . uniqid('wav_') . '.wav';
        
        // Try to use FFmpeg if available
        if (function_exists('exec')) {
            $command = "ffmpeg -i " . escapeshellarg($file_path) . " -acodec pcm_s16le -ac 1 -ar 16000 " . escapeshellarg($wav_file);
            
            @exec($command, $output, $return_var);
            
            if ($return_var === 0 && file_exists($wav_file)) {
                return $wav_file;
            }
        }
        
        // Fallback: copy the file (this won't actually convert it)
        copy($file_path, $wav_file);
        return $wav_file;
    }
    
    /**
     * Get built-in model path
     */
    private function get_built_in_model_path($language) {
        // Models directory
        $models_dir = WSATC_PLUGIN_DIR . 'models/built_in';
        
        // Return model path
        return $models_dir . '/' . $language . '.json';
    }
    
    /**
     * Get Vosk model path
     */
    private function get_vosk_model_path($language) {
        // Models directory
        $models_dir = WSATC_PLUGIN_DIR . 'models/vosk';
        
        // Language to model mapping
        $language_models = array(
            'en' => 'vosk-model-small-en-us-0.15',
            'es' => 'vosk-model-small-es-0.42',
            'fr' => 'vosk-model-small-fr-0.22',
            'de' => 'vosk-model-small-de-0.15',
            'ru' => 'vosk-model-small-ru-0.22',
            'zh' => 'vosk-model-small-cn-0.22',
            'pt' => 'vosk-model-small-pt-0.3',
            'it' => 'vosk-model-small-it-0.22',
            'nl' => 'vosk-model-small-nl-0.22',
            'ja' => 'vosk-model-small-ja-0.22',
            'hi' => 'vosk-model-small-hi-0.22',
            'bn' => 'vosk-model-small-bn-0.22'
        );
        
        // Get model name
        $model_name = isset($language_models[$language]) ? $language_models[$language] : $language_models['en'];
        
        // Return model path
        return $models_dir . '/' . $model_name;
    }
    
    /**
     * Get Whisper model path
     */
    private function get_whisper_model_path($language) {
        // Models directory
        $models_dir = WSATC_PLUGIN_DIR . 'models/whisper';
        
        // Return model path
        return $models_dir . '/' . (($language === 'en') ? 'ggml-base.en.bin' : 'ggml-base.bin');
    }

    /**
     * Check if Vosk is available
     */
    private function check_vosk_available() {
        if (!function_exists('exec')) {
            return false;
        }
        
        // Try to execute vosk-transcriber
        $command = "vosk-transcriber --version";
        @exec($command, $output, $return_var);
        
        return $return_var === 0;
    }

    /**
     * Check if Whisper.cpp is available
     */
    private function check_whisper_available() {
        if (!function_exists('exec')) {
            return false;
        }
        
        // Try to execute whisper
        $command = "whisper --version";
        @exec($command, $output, $return_var);
        
        return $return_var === 0;
    }
}

