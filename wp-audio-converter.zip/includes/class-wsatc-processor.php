<?php
/**
 * Audio processor class
 */
class WSATC_Processor {
    
    /**
     * Initialize processor
     */
    public function init() {
        // Add AJAX handlers
        add_action('wp_ajax_wsatc_process_audio', array($this, 'process_audio'));
        
        // Add missing AJAX handlers
        add_action('wp_ajax_wsatc_get_recent_transcriptions', array($this, 'get_recent_transcriptions'));
        add_action('wp_ajax_wsatc_get_transcription', array($this, 'get_transcription'));
        add_action('wp_ajax_wsatc_delete_transcription', array($this, 'delete_transcription'));
        add_action('wp_ajax_wsatc_create_post', array($this, 'create_post'));
        
        // Add cron job for cleanup
        if (!wp_next_scheduled('wsatc_cleanup_temp_files')) {
            wp_schedule_event(time(), 'daily', 'wsatc_cleanup_temp_files');
        }
        add_action('wsatc_cleanup_temp_files', array($this, 'cleanup_temp_files'));
    }
    
    /**
     * Process audio file
     */
    public function process_audio() {
        // Check nonce
        if (!check_ajax_referer('wsatc_admin_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => __('Security check failed', 'wp-smart-audio-converter')));
        }
        
        // Check file path
        if (empty($_POST['file_path'])) {
            wp_send_json_error(array('message' => __('No file path provided', 'wp-smart-audio-converter')));
        }
        
        $file_path = sanitize_text_field($_POST['file_path']);
        if (!file_exists($file_path)) {
            wp_send_json_error(array('message' => __('File not found', 'wp-smart-audio-converter')));
        }
        
        // Get options
        $language = isset($_POST['language']) ? sanitize_text_field($_POST['language']) : 'en';
        $add_timestamps = isset($_POST['add_timestamps']) ? (bool) $_POST['add_timestamps'] : true;
        $seo_optimize = isset($_POST['seo_optimize']) ? (bool) $_POST['seo_optimize'] : true;
        
        // Create temp directory
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/wsatc-audio/temp';
        if (!file_exists($temp_dir)) {
            wp_mkdir_p($temp_dir);
        }
        
        // Generate unique ID for this transcription
        $transcription_id = uniqid('wsatc_');
        
        // Convert audio to WAV format if needed
        $file_info = pathinfo($file_path);
        $file_extension = strtolower($file_info['extension']);
        
        $wav_file = $temp_dir . '/' . $transcription_id . '.wav';
        
        if ($file_extension !== 'wav') {
            // Convert to WAV using FFmpeg
            $ffmpeg_command = "ffmpeg -i " . escapeshellarg($file_path) . " -acodec pcm_s16le -ac 1 -ar 16000 " . escapeshellarg($wav_file);
            exec($ffmpeg_command, $output, $return_var);
            
            if ($return_var !== 0) {
                wp_send_json_error(array('message' => __('Failed to convert audio file', 'wp-smart-audio-converter')));
            }
        } else {
            // Copy the file
            copy($file_path, $wav_file);
        }
        
        // Get transcriber
        $transcriber = new WSATC_Transcriber();
        
        // Process audio
        $result = $transcriber->transcribe($wav_file, $language);
        
        if (!$result['success']) {
            wp_send_json_error(array('message' => $result['message']));
        }
        
        // Post-process text
        $text = $result['text'];
        $segments = $result['segments'];
        
        // Add timestamps if requested
        if ($add_timestamps && !empty($segments)) {
            $text_with_timestamps = '';
            foreach ($segments as $segment) {
                $start_time = $this->format_time($segment['start']);
                $text_with_timestamps .= '[' . $start_time . '] ' . $segment['text'] . "\n\n";
            }
            $text = $text_with_timestamps;
        }
        
        // SEO optimization if requested
        if ($seo_optimize) {
            $text = $this->optimize_for_seo($text);
        }
        
        // Save transcription
        $transcription_data = array(
            'id' => $transcription_id,
            'file_name' => basename($file_path),
            'language' => $language,
            'text' => $text,
            'segments' => $segments,
            'date' => current_time('mysql'),
            'add_timestamps' => $add_timestamps,
            'seo_optimize' => $seo_optimize
        );
        
        $this->save_transcription($transcription_id, $transcription_data);
        
        // Return result
        wp_send_json_success(array(
            'message' => __('Audio processed successfully', 'wp-smart-audio-converter'),
            'transcription_id' => $transcription_id,
            'text' => $text,
            'segments' => $segments
        ));
    }
    
    /**
     * Get recent transcriptions
     */
    public function get_recent_transcriptions() {
        // Check nonce
        if (!check_ajax_referer('wsatc_admin_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => __('Security check failed', 'wp-smart-audio-converter')));
        }
        
        // Get transcriptions
        $transcriptions = get_option('wsatc_transcriptions', array());
        
        // Sort by date (newest first)
        uasort($transcriptions, function($a, $b) {
            return strtotime($b['date']) - strtotime($a['date']);
        });
        
        // Limit to 10 recent transcriptions
        $recent_transcriptions = array_slice($transcriptions, 0, 10, true);
        
        // Return result
        wp_send_json_success(array(
            'transcriptions' => array_values($recent_transcriptions)
        ));
    }
    
    /**
     * Get transcription
     */
    public function get_transcription() {
        // Check nonce
        if (!check_ajax_referer('wsatc_admin_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => __('Security check failed', 'wp-smart-audio-converter')));
        }
        
        // Check ID
        if (empty($_POST['id'])) {
            wp_send_json_error(array('message' => __('No transcription ID provided', 'wp-smart-audio-converter')));
        }
        
        $transcription_id = sanitize_text_field($_POST['id']);
        
        // Get transcriptions
        $transcriptions = get_option('wsatc_transcriptions', array());
        
        // Check if transcription exists
        if (!isset($transcriptions[$transcription_id])) {
            wp_send_json_error(array('message' => __('Transcription not found', 'wp-smart-audio-converter')));
        }
        
        // Return result
        wp_send_json_success($transcriptions[$transcription_id]);
    }
    
    /**
     * Delete transcription
     */
    public function delete_transcription() {
        // Check nonce
        if (!check_ajax_referer('wsatc_admin_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => __('Security check failed', 'wp-smart-audio-converter')));
        }
        
        // Check ID
        if (empty($_POST['id'])) {
            wp_send_json_error(array('message' => __('No transcription ID provided', 'wp-smart-audio-converter')));
        }
        
        $transcription_id = sanitize_text_field($_POST['id']);
        
        // Get transcriptions
        $transcriptions = get_option('wsatc_transcriptions', array());
        
        // Check if transcription exists
        if (!isset($transcriptions[$transcription_id])) {
            wp_send_json_error(array('message' => __('Transcription not found', 'wp-smart-audio-converter')));
        }
        
        // Delete transcription
        unset($transcriptions[$transcription_id]);
        update_option('wsatc_transcriptions', $transcriptions);
        
        // Return result
        wp_send_json_success(array(
            'message' => __('Transcription deleted successfully', 'wp-smart-audio-converter')
        ));
    }
    
    /**
     * Create post from transcription
     */
    public function create_post() {
        // Check nonce
        if (!check_ajax_referer('wsatc_admin_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => __('Security check failed', 'wp-smart-audio-converter')));
        }
        
        // Check text
        if (empty($_POST['text'])) {
            wp_send_json_error(array('message' => __('No text provided', 'wp-smart-audio-converter')));
        }
        
        $text = wp_kses_post($_POST['text']);
        $title = !empty($_POST['title']) ? sanitize_text_field($_POST['title']) : __('Transcription', 'wp-smart-audio-converter');
        
        // Create post
        $post_id = wp_insert_post(array(
            'post_title' => $title,
            'post_content' => $text,
            'post_status' => 'draft',
            'post_type' => 'post'
        ));
        
        if (is_wp_error($post_id)) {
            wp_send_json_error(array('message' => $post_id->get_error_message()));
        }
        
        // Return result
        wp_send_json_success(array(
            'message' => __('Post created successfully', 'wp-smart-audio-converter'),
            'post_id' => $post_id,
            'edit_url' => admin_url('post.php?post=' . $post_id . '&action=edit')
        ));
    }
    
    /**
     * Format time in seconds to MM:SS format
     */
    private function format_time($seconds) {
        $minutes = floor($seconds / 60);
        $seconds = $seconds % 60;
        return sprintf('%02d:%02d', $minutes, $seconds);
    }
    
    /**
     * Optimize text for SEO
     */
    public function optimize_for_seo($text) {
        // Split text into paragraphs
        $paragraphs = explode("\n\n", $text);
        
        // Initialize optimized text
        $optimized_text = '';
        
        // Add title
        $optimized_text .= "<h1>Transcription</h1>\n\n";
        
        // Process paragraphs
        $section_count = 0;
        $current_section = '';
        
        foreach ($paragraphs as $index => $paragraph) {
            // Skip empty paragraphs
            if (empty(trim($paragraph))) {
                continue;
            }
            
            // Add to current section
            $current_section .= $paragraph . "\n\n";
            
            // Every 3-5 paragraphs, create a new section with a heading
            if ($index > 0 && $index % 4 === 0) {
                $section_count++;
                
                // Extract keywords from the section
                $keywords = $this->extract_keywords($current_section);
                
                // Generate heading
                $heading = $this->generate_heading($keywords, $section_count);
                
                // Add heading and section to optimized text
                $optimized_text .= "<h2>" . $heading . "</h2>\n\n" . $current_section;
                
                // Reset current section
                $current_section = '';
            }
        }
        
        // Add remaining section
        if (!empty($current_section)) {
            $section_count++;
            $keywords = $this->extract_keywords($current_section);
            $heading = $this->generate_heading($keywords, $section_count);
            $optimized_text .= "<h2>" . $heading . "</h2>\n\n" . $current_section;
        }
        
        return $optimized_text;
    }
    
    /**
     * Extract keywords from text
     */
    private function extract_keywords($text) {
        // Remove common words
        $stop_words = array('a', 'an', 'the', 'and', 'or', 'but', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'in', 'on', 'at', 'to', 'for', 'with', 'by', 'about', 'against', 'between', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'from', 'up', 'down', 'of', 'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just', 'don', 'should', 'now');
        
        // Convert to lowercase and remove punctuation
        $text = strtolower($text);
        $text = preg_replace('/[^\w\s]/', '', $text);
        
        // Split into words
        $words = preg_split('/\s+/', $text);
        
        // Remove stop words
        $words = array_diff($words, $stop_words);
        
        // Count word frequency
        $word_count = array_count_values($words);
        
        // Sort by frequency
        arsort($word_count);
        
        // Return top 5 keywords
        return array_slice(array_keys($word_count), 0, 5);
    }
    
    /**
     * Generate heading from keywords
     */
    private function generate_heading($keywords, $section_count) {
        // If no keywords, use generic heading
        if (empty($keywords)) {
            return 'Section ' . $section_count;
        }
        
        // Use top keyword as heading
        $heading = ucfirst($keywords[0]);
        
        // Add second keyword if available
        if (isset($keywords[1])) {
            $heading .= ' and ' . ucfirst($keywords[1]);
        }
        
        return $heading;
    }
    
    /**
     * Save transcription
     */
    private function save_transcription($transcription_id, $transcription_data) {
        $transcriptions = get_option('wsatc_transcriptions', array());
        $transcriptions[$transcription_id] = $transcription_data;
        update_option('wsatc_transcriptions', $transcriptions);
    }
    
    /**
     * Cleanup temporary files
     */
    public function cleanup_temp_files() {
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/wsatc-audio/temp';
        
        if (!file_exists($temp_dir)) {
            return;
        }
        
        // Get all files in temp directory
        $files = glob($temp_dir . '/*');
        
        // Get current time
        $current_time = time();
        
        // Delete files older than 24 hours
        foreach ($files as $file) {
            if (is_file($file)) {
                $file_time = filemtime($file);
                if ($current_time - $file_time > 24 * 60 * 60) {
                    @unlink($file);
                }
            }
        }
    }
}

