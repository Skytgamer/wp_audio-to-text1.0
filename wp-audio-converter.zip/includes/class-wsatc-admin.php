<?php
/**
 * Admin class
 */
class WSATC_Admin {
    
    /**
     * Initialize admin
     */
    public function init() {
        // Add admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Add admin scripts
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // Add settings
        add_action('admin_init', array($this, 'register_settings'));
        
        // Add admin notices
        add_action('admin_notices', array($this, 'admin_notices'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Audio to Text Converter', 'wp-smart-audio-converter'),
            __('Audio to Text', 'wp-smart-audio-converter'),
            'manage_options',
            'wp-smart-audio-converter',
            array($this, 'render_admin_page'),
            'dashicons-microphone',
            30
        );
        
        add_submenu_page(
            'wp-smart-audio-converter',
            __('Settings', 'wp-smart-audio-converter'),
            __('Settings', 'wp-smart-audio-converter'),
            'manage_options',
            'wp-smart-audio-converter-settings',
            array($this, 'render_settings_page')
        );
    }
    
    /**
     * Enqueue admin scripts
     */
    public function enqueue_scripts($hook) {
        // Only load on plugin pages
        if (strpos($hook, 'wp-smart-audio-converter') === false) {
            return;
        }
        
        // Enqueue styles
        wp_enqueue_style(
            'wsatc-admin-style',
            WSATC_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            WSATC_VERSION
        );
        
        // Enqueue scripts
        wp_enqueue_script(
            'wsatc-admin-script',
            WSATC_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery', 'wp-util'),
            WSATC_VERSION,
            true
        );
        
        // Localize script
        wp_localize_script('wsatc-admin-script', 'wsatc_params', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wsatc_admin_nonce'),
            'i18n' => array(
                'uploading' => __('Uploading...', 'wp-smart-audio-converter'),
                'processing' => __('Processing...', 'wp-smart-audio-converter'),
                'success' => __('Success!', 'wp-smart-audio-converter'),
                'error' => __('Error:', 'wp-smart-audio-converter'),
                'confirm_delete' => __('Are you sure you want to delete this transcription?', 'wp-smart-audio-converter')
            )
        ));
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('wsatc_settings', 'wsatc_engine_type');
        register_setting('wsatc_settings', 'wsatc_default_language');
        register_setting('wsatc_settings', 'wsatc_max_file_size');
        register_setting('wsatc_settings', 'wsatc_seo_optimization');
        register_setting('wsatc_settings', 'wsatc_add_timestamps');
        
        add_settings_section(
            'wsatc_general_settings',
            __('General Settings', 'wp-smart-audio-converter'),
            array($this, 'render_general_settings_section'),
            'wsatc_settings'
        );
        
        add_settings_field(
            'wsatc_engine_type',
            __('Transcription Engine', 'wp-smart-audio-converter'),
            array($this, 'render_engine_type_field'),
            'wsatc_settings',
            'wsatc_general_settings'
        );
        
        add_settings_field(
            'wsatc_default_language',
            __('Default Language', 'wp-smart-audio-converter'),
            array($this, 'render_default_language_field'),
            'wsatc_settings',
            'wsatc_general_settings'
        );
        
        add_settings_field(
            'wsatc_max_file_size',
            __('Maximum File Size (MB)', 'wp-smart-audio-converter'),
            array($this, 'render_max_file_size_field'),
            'wsatc_settings',
            'wsatc_general_settings'
        );
        
        add_settings_field(
            'wsatc_seo_optimization',
            __('SEO Optimization', 'wp-smart-audio-converter'),
            array($this, 'render_seo_optimization_field'),
            'wsatc_settings',
            'wsatc_general_settings'
        );
        
        add_settings_field(
            'wsatc_add_timestamps',
            __('Add Timestamps', 'wp-smart-audio-converter'),
            array($this, 'render_add_timestamps_field'),
            'wsatc_settings',
            'wsatc_general_settings'
        );
    }
    
    /**
     * Render general settings section
     */
    public function render_general_settings_section() {
        echo '<p>' . __('Configure the audio to text converter settings.', 'wp-smart-audio-converter') . '</p>';
    }
    
    /**
     * Render engine type field
     */
    public function render_engine_type_field() {
        $engine_type = get_option('wsatc_engine_type', 'vosk');
        ?>
        <select name="wsatc_engine_type" id="wsatc_engine_type">
            <option value="vosk" <?php selected($engine_type, 'vosk'); ?>><?php _e('Vosk (Offline)', 'wp-smart-audio-converter'); ?></option>
            <option value="whisper" <?php selected($engine_type, 'whisper'); ?>><?php _e('Whisper.cpp (Offline)', 'wp-smart-audio-converter'); ?></option>
        </select>
        <p class="description"><?php _e('Select the transcription engine to use.', 'wp-smart-audio-converter'); ?></p>
        <?php
    }
    
    /**
     * Render default language field
     */
    public function render_default_language_field() {
        $default_language = get_option('wsatc_default_language', 'en');
        $languages = array(
            'en' => __('English', 'wp-smart-audio-converter'),
            'es' => __('Spanish', 'wp-smart-audio-converter'),
            'fr' => __('French', 'wp-smart-audio-converter'),
            'de' => __('German', 'wp-smart-audio-converter'),
            'it' => __('Italian', 'wp-smart-audio-converter'),
            'pt' => __('Portuguese', 'wp-smart-audio-converter'),
            'ru' => __('Russian', 'wp-smart-audio-converter'),
            'zh' => __('Chinese', 'wp-smart-audio-converter'),
            'ja' => __('Japanese', 'wp-smart-audio-converter'),
            'ko' => __('Korean', 'wp-smart-audio-converter'),
            'hi' => __('Hindi', 'wp-smart-audio-converter'),
            'bn' => __('Bengali', 'wp-smart-audio-converter')
        );
        ?>
        <select name="wsatc_default_language" id="wsatc_default_language">
            <?php foreach ($languages as $code => $name) : ?>
                <option value="<?php echo esc_attr($code); ?>" <?php selected($default_language, $code); ?>><?php echo esc_html($name); ?></option>
            <?php endforeach; ?>
        </select>
        <p class="description"><?php _e('Select the default language for transcription.', 'wp-smart-audio-converter'); ?></p>
        <?php
    }
    
    /**
     * Render max file size field
     */
    public function render_max_file_size_field() {
        $max_file_size = get_option('wsatc_max_file_size', 50);
        ?>
        <input type="number" name="wsatc_max_file_size" id="wsatc_max_file_size" value="<?php echo esc_attr($max_file_size); ?>" min="1" max="500" />
        <p class="description"><?php _e('Maximum file size in MB.', 'wp-smart-audio-converter'); ?></p>
        <?php
    }
    
    /**
     * Render SEO optimization field
     */
    public function render_seo_optimization_field() {
        $seo_optimization = get_option('wsatc_seo_optimization', 1);
        ?>
        <input type="checkbox" name="wsatc_seo_optimization" id="wsatc_seo_optimization" value="1" <?php checked($seo_optimization, 1); ?> />
        <label for="wsatc_seo_optimization"><?php _e('Enable SEO optimization for transcribed text', 'wp-smart-audio-converter'); ?></label>
        <p class="description"><?php _e('Automatically structure text with headings and paragraphs.', 'wp-smart-audio-converter'); ?></p>
        <?php
    }
    
    /**
     * Render add timestamps field
     */
    public function render_add_timestamps_field() {
        $add_timestamps = get_option('wsatc_add_timestamps', 1);
        ?>
        <input type="checkbox" name="wsatc_add_timestamps" id="wsatc_add_timestamps" value="1" <?php checked($add_timestamps, 1); ?> />
        <label for="wsatc_add_timestamps"><?php _e('Add timestamps to transcribed text', 'wp-smart-audio-converter'); ?></label>
        <p class="description"><?php _e('Add timestamps to mark different sections of the transcription.', 'wp-smart-audio-converter'); ?></p>
        <?php
    }
    
    /**
     * Render admin page
     */
    public function render_admin_page() {
        ?>
        <div class="wrap wsatc-admin">
            <h1><?php _e('Audio to Text Converter', 'wp-smart-audio-converter'); ?></h1>
            
            <div class="wsatc-admin-container">
                <div class="wsatc-admin-main">
                    <div class="wsatc-card">
                        <h2><?php _e('Upload Audio File', 'wp-smart-audio-converter'); ?></h2>
                        <div class="wsatc-dropzone" id="wsatc-dropzone">
                            <div class="wsatc-dropzone-inner">
                                <span class="dashicons dashicons-microphone"></span>
                                <p><?php _e('Drag & drop audio file here or click to upload', 'wp-smart-audio-converter'); ?></p>
                                <p class="wsatc-small"><?php _e('Supported formats: MP3, WAV, OGG, M4A', 'wp-smart-audio-converter'); ?></p>
                            </div>
                            <input type="file" id="wsatc-file-input" class="wsatc-file-input" accept=".mp3,.wav,.ogg,.m4a" />
                        </div>
                        
                        <div class="wsatc-upload-options">
                            <div class="wsatc-option">
                                <label for="wsatc-language"><?php _e('Language:', 'wp-smart-audio-converter'); ?></label>
                                <select id="wsatc-language">
                                    <option value="en"><?php _e('English', 'wp-smart-audio-converter'); ?></option>
                                    <option value="es"><?php _e('Spanish', 'wp-smart-audio-converter'); ?></option>
                                    <option value="fr"><?php _e('French', 'wp-smart-audio-converter'); ?></option>
                                    <option value="de"><?php _e('German', 'wp-smart-audio-converter'); ?></option>
                                    <option value="it"><?php _e('Italian', 'wp-smart-audio-converter'); ?></option>
                                    <option value="pt"><?php _e('Portuguese', 'wp-smart-audio-converter'); ?></option>
                                    <option value="ru"><?php _e('Russian', 'wp-smart-audio-converter'); ?></option>
                                    <option value="zh"><?php _e('Chinese', 'wp-smart-audio-converter'); ?></option>
                                    <option value="ja"><?php _e('Japanese', 'wp-smart-audio-converter'); ?></option>
                                    <option value="ko"><?php _e('Korean', 'wp-smart-audio-converter'); ?></option>
                                    <option value="hi"><?php _e('Hindi', 'wp-smart-audio-converter'); ?></option>
                                    <option value="bn"><?php _e('Bengali', 'wp-smart-audio-converter'); ?></option>
                                </select>
                            </div>
                            
                            <div class="wsatc-option">
                                <label>
                                    <input type="checkbox" id="wsatc-add-timestamps" checked />
                                    <?php _e('Add timestamps', 'wp-smart-audio-converter'); ?>
                                </label>
                            </div>
                            
                            <div class="wsatc-option">
                                <label>
                                    <input type="checkbox" id="wsatc-seo-optimize" checked />
                                    <?php _e('SEO optimization', 'wp-smart-audio-converter'); ?>
                                </label>
                            </div>
                        </div>
                        
                        <div class="wsatc-actions">
                            <button id="wsatc-upload-btn" class="button button-primary"><?php _e('Upload & Transcribe', 'wp-smart-audio-converter'); ?></button>
                        </div>
                    </div>
                    
                    <div class="wsatc-card wsatc-hidden" id="wsatc-progress-card">
                        <h2><?php _e('Processing Audio', 'wp-smart-audio-converter'); ?></h2>
                        <div class="wsatc-progress">
                            <div class="wsatc-progress-bar" id="wsatc-progress-bar"></div>
                        </div>
                        <p id="wsatc-progress-status"><?php _e('Uploading...', 'wp-smart-audio-converter'); ?></p>
                    </div>
                    
                    <div class="wsatc-card wsatc-hidden" id="wsatc-result-card">
                        <h2><?php _e('Transcription Result', 'wp-smart-audio-converter'); ?></h2>
                        <div class="wsatc-result-actions">
                            <button id="wsatc-edit-btn" class="button button-secondary"><?php _e('Edit Text', 'wp-smart-audio-converter'); ?></button>
                            <button id="wsatc-copy-btn" class="button button-secondary"><?php _e('Copy Text', 'wp-smart-audio-converter'); ?></button>
                            <button id="wsatc-create-post-btn" class="button button-primary"><?php _e('Create Post', 'wp-smart-audio-converter'); ?></button>
                            <div class="wsatc-export-dropdown">
                                <button id="wsatc-export-btn" class="button button-secondary"><?php _e('Export', 'wp-smart-audio-converter'); ?></button>
                                <div class="wsatc-export-options">
                                    <a href="#" id="wsatc-export-txt"><?php _e('Export as TXT', 'wp-smart-audio-converter'); ?></a>
                                    <a href="#" id="wsatc-export-pdf"><?php _e('Export as PDF', 'wp-smart-audio-converter'); ?></a>
                                </div>
                            </div>
                        </div>
                        <div class="wsatc-result-content">
                            <div id="wsatc-result-view" class="wsatc-result-view"></div>
                            <div id="wsatc-result-edit" class="wsatc-result-edit wsatc-hidden">
                                <textarea id="wsatc-result-textarea"></textarea>
                                <div class="wsatc-edit-actions">
                                    <button id="wsatc-save-edit-btn" class="button button-primary"><?php _e('Save Changes', 'wp-smart-audio-converter'); ?></button>
                                    <button id="wsatc-cancel-edit-btn" class="button button-secondary"><?php _e('Cancel', 'wp-smart-audio-converter'); ?></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="wsatc-admin-sidebar">
                    <div class="wsatc-card">
                        <h2><?php _e('Recent Transcriptions', 'wp-smart-audio-converter'); ?></h2>
                        <div id="wsatc-recent-transcriptions">
                            <p><?php _e('No recent transcriptions found.', 'wp-smart-audio-converter'); ?></p>
                        </div>
                    </div>
                    
                    <div class="wsatc-card">
                        <h2><?php _e('System Status', 'wp-smart-audio-converter'); ?></h2>
                        <div class="wsatc-system-status">
                            <?php
                            $requirements_met = get_option('wsatc_requirements_met', false);
                            $requirements_messages = get_option('wsatc_requirements_messages', array());
                            
                            if ($requirements_met) {
                                echo '<div class="wsatc-status-ok">';
                                echo '<span class="dashicons dashicons-yes-alt"></span>';
                                echo '<p>' . __('All system requirements are met.', 'wp-smart-audio-converter') . '</p>';
                                echo '</div>';
                            } else {
                                echo '<div class="wsatc-status-error">';
                                echo '<span class="dashicons dashicons-warning"></span>';
                                echo '<p>' . __('Some system requirements are not met:', 'wp-smart-audio-converter') . '</p>';
                                echo '<ul>';
                                foreach ($requirements_messages as $message) {
                                    echo '<li>' . esc_html($message) . '</li>';
                                }
                                echo '</ul>';
                                echo '</div>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        ?>
        <div class="wrap wsatc-admin">
            <h1><?php _e('Audio to Text Converter Settings', 'wp-smart-audio-converter'); ?></h1>
            
            <form method="post" action="options.php">
                <?php
                settings_fields('wsatc_settings');
                do_settings_sections('wsatc_settings');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }
    
    /**
     * Admin notices
     */
    public function admin_notices() {
        $requirements_met = get_option('wsatc_requirements_met', false);
        $requirements_messages = get_option('wsatc_requirements_messages', array());
        
        if (!$requirements_met && !empty($requirements_messages)) {
            ?>
            <div class="notice notice-error">
                <p><strong><?php _e('WP Smart Audio to Text Converter:', 'wp-smart-audio-converter'); ?></strong> <?php _e('Some system requirements are not met:', 'wp-smart-audio-converter'); ?></p>
                <ul>
                    <?php foreach ($requirements_messages as $message) : ?>
                        <li><?php echo esc_html($message); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php
        }
    }
}

