"use client"

import  from "../assets/js/frontend"

export default function SyntheticV0PageForDeployment() {
  return < />
}